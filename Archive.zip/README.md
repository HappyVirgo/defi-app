## Getting Started

Install the dependencies first. Run:

```bash
npm i
```

Then, run the development server:

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.


## Changing Data
You will find the statc data on ```data``` folder. Change the array elements to see the results.
