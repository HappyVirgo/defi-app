import React from 'react'
import Projects from '../components/Projects/Projects'

const projects = () => {
    return (
        <div>
            <Projects />
        </div>
    )
}

export default projects
