exports.id = 410;
exports.ids = [410];
exports.modules = {

/***/ 2410:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": function() { return /* binding */ Projects_Projects; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: ./node_modules/next/dist/client/router.js
var client_router = __webpack_require__(2441);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./data/projectsData.tsx
var projectsData = __webpack_require__(3225);
// EXTERNAL MODULE: ./components/Meta.tsx
var Meta = __webpack_require__(1112);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Projects/ProjectGroup.tsx





const ProjectGroup = props => {
  const projects = props.projectGroup;
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "grid gap-36 grid-cols-1 lg:grid-cols-2 mb-36 px-4 xl:px-0",
    children: projects.map((project, index) => {
      return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: index === 3 ? 'md:-mt-48' : '',
        style: {
          gridColumn: index === 4 && window.innerWidth > 768 ? 'span 2' : 'span 1'
        },
        children: [(index === 0 || index === 3) && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "bg-gray-200",
          children: /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "pl-2 pt-2 md:pl-4 md:pt-4 lg:pl-8 lg:pt-8 flex",
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: project.image,
              alt: project.name,
              width: 498,
              height: 570,
              objectFit: "cover"
            })
          })
        }), (index === 1 || index === 2) && /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: project.image,
            alt: project.name,
            width: 497,
            height: 380,
            objectFit: "cover"
          })
        }), index === 4 && /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: project.image,
            alt: project.name,
            width: 955,
            height: 600,
            objectFit: "cover"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
          className: "text-2xl font-bold mt-4",
          children: [project.name, " \u2014"]
        }), /*#__PURE__*/jsx_runtime_.jsx("p", {
          className: "mt-2 " + (index === 4 ? 'md:w-1/2' : 'w-full'),
          children: project.excerpt
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mt-8 text-xl font-medium font-neueMachina",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: project.projectLink,
            target: "_blank",
            children: "View Project \u2197"
          })
        })]
      }, index);
    })
  });
}; // style={{ gridColumn: 'span 2' }}


/* harmony default export */ var Projects_ProjectGroup = (ProjectGroup);
;// CONCATENATED MODULE: ./components/Projects/Projects.tsx










const Projects = () => {
  const router = (0,client_router.useRouter)();
  const isProjectRoute = router.pathname === '/projects' ? true : false;
  const projects = projectsData/* ProjectData */.H;
  let chunk = 5;
  const {
    0: groupedProjects,
    1: setGroupedProjects
  } = (0,external_react_.useState)([]);
  (0,external_react_.useEffect)(() => {
    let tempProjects = [];

    for (let i = 0; i < projects.length; i += chunk) {
      tempProjects = [...tempProjects, projects.slice(i, i + chunk)];
    }

    if (!isProjectRoute) {
      if (window.innerWidth < 768) {
        const slicedProjects = [tempProjects[0].slice(0, 2)];
        setGroupedProjects(slicedProjects);
      } else {
        setGroupedProjects([tempProjects[0]]);
      }
    } else {
      setGroupedProjects(tempProjects);
    }
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Meta/* default */.Z, {
      title: 'Projects of The Defi Network LLC'
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      id: "projects",
      className: "mt-20 lg:mt-32 lg:max-w-4xl xl:max-w-5xl xl:pl-8 2xl:max-w-7xl lg:mx-auto",
      children: [!isProjectRoute && /*#__PURE__*/jsx_runtime_.jsx("h2", {
        className: "font-bold pl-4 lg:pl-0 text-2xl mb-8",
        children: "Past Projects"
      }), isProjectRoute && /*#__PURE__*/jsx_runtime_.jsx("h1", {
        className: "font-bold pl-4 lg:pl-0 text-4/5xl leading-tight lg:text-5xl mb-12",
        children: "All Projects"
      }), groupedProjects.map((groupProj, index) => {
        return /*#__PURE__*/jsx_runtime_.jsx(Projects_ProjectGroup, {
          projectGroup: groupProj
        }, index);
      }), !isProjectRoute && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "mt-32 text-2xl font-medium font-neueMachina pl-4 lg:pl-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/projects",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: "View all projects \u2197"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "bg-gray-100 h-0.5 mt-8"
        })]
      })]
    })]
  });
};

/* harmony default export */ var Projects_Projects = (Projects);

/***/ })

};
;