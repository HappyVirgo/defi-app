(function() {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 5990:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _app; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
;// CONCATENATED MODULE: ./components/Layout/Navbar.tsx






const Navbar = () => {
  const {
    0: showNavLinks,
    1: setShowNavLinks
  } = (0,external_react_.useState)(false);
  (0,external_react_.useEffect)(() => {
    if (window.innerWidth >= 768) {
      setShowNavLinks(true);
    }
  }, []);

  const closeNavlinks = () => {
    if (window.innerWidth < 768) {
      setShowNavLinks(false);
    }
  };

  return /*#__PURE__*/jsx_runtime_.jsx("nav", {
    className: "fixed md:relative p-4 inset-x-0 top-0 z-50 bg-white",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex justify-between items-center px-0 md:px-4",
      children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
        role: "link",
        className: "cursor-pointer",
        children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
          href: "/",
          "aria-role": "home",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: "/logo.svg",
              alt: "defi network llc logo",
              width: 202,
              height: 48
            })
          })
        })
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
        className: "-mt-2 md:hidden flex justify-center items-center",
        onClick: () => setShowNavLinks(!showNavLinks),
        children: [!showNavLinks && /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/menu.svg",
          width: 24,
          height: 24,
          alt: "open mobile menu"
        }), showNavLinks && /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/closeMenu.svg",
          width: 24,
          height: 24,
          alt: "close mobile menu"
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: `transition-opacity-top duration-500 ease-out pb-12 md:pb-0 flex fixed left-0 right-0 top-0 -z-1 lg:z-10 pt-24 md:pt-0 bg-white sapce-y-4 md:space-y-0 
                                 md:flex flex-col md:flex-row md:relative flex-1 justify-center items-center font-medium ` + (showNavLinks ? 'opacity-1 bottom-0' : 'opacity-0 -top-full bottom-full'),
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "md:mr-4 mb-4 md:mb-0 lg:mr-8 text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/#projects",
            onClick: closeNavlinks,
            children: "Projects"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "md:mr-4 mb-4 md:mb-0 lg:mr-8 text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/#services",
            onClick: closeNavlinks,
            children: "Services"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "md:mr-4 mb-4 md:mb-0 lg:mr-8 text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/#technologies",
            onClick: closeNavlinks,
            children: "Technologies"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "md:mr-4 mb-4 md:mb-0 lg:mr-8 text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/#team",
            onClick: closeNavlinks,
            children: "Team"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "md:mr-4 mb-4 md:mb-0 lg:mr-8 text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/#partnerships",
            onClick: closeNavlinks,
            children: "Partnerships"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "text-center",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            href: "/#faq",
            onClick: closeNavlinks,
            children: "FAQ"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mt-auto block cursor-pointer md:hidden border-solid border-2 w-4/5 text-center  py-2 text-defi-blue transition duration-500 ease-in-out hover:bg-defi-blue hover:text-white border-defi-blue  font-bold",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: "/#contact",
            children: /*#__PURE__*/jsx_runtime_.jsx("a", {
              className: "hover:text-white",
              onClick: closeNavlinks,
              children: "Get in touch"
            })
          })
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: "/#contact",
        children: /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "cursor-pointer hidden md:block border-solid border-2 px-3 py-2 text-defi-blue transition duration-500 ease-in-out hover:bg-defi-blue hover:text-white border-defi-blue font-bold",
          children: /*#__PURE__*/jsx_runtime_.jsx("a", {
            className: "hover:text-white",
            children: "Get in touch"
          })
        })
      })]
    })
  });
};

/* harmony default export */ var Layout_Navbar = (Navbar);
;// CONCATENATED MODULE: external "formik"
var external_formik_namespaceObject = require("formik");;
;// CONCATENATED MODULE: ./components/ContactForm.tsx







const ContactForm = () => {
  const {
    0: success,
    1: setSuccess
  } = (0,external_react_.useState)(false);

  const validate = values => {
    let errors = {};

    if (!values.name) {
      errors.name = 'Your name is required';
    }

    if (!values.message) {
      errors.message = 'Project description is required';
    }

    if (!values.email) {
      errors.email = 'Your email is required';
    } else if (!isValidEmail(values.email)) {
      errors.email = 'Invalid email address';
    }

    return errors;
  };

  const isValidEmail = (email = '') => {
    const regex = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return regex.test(email);
  };

  const formik = (0,external_formik_namespaceObject.useFormik)({
    initialValues: {
      name: '',
      email: '',
      message: ''
    },
    validate,
    onSubmit: (values, actions) => {
      (async () => {
        try {
          const rawResponse = await fetch('https://thedefi.network/api/sendMail.php/sendMail', {
            method: 'POST',
            headers: {
              'Accept': 'application/json',
              'Content-Type': 'application/json'
            },
            body: JSON.stringify(values)
          });
          const content = await rawResponse.json();

          if (content) {
            setSuccess(true);
            setTimeout(() => {
              setSuccess(false);
              actions.resetForm({
                values: {
                  name: '',
                  email: '',
                  message: ''
                }
              });
            }, 5000);
          }
        } catch (error) {
          alert('Error on sending email');
        }
      })();
    }
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    id: "contact",
    className: "mt-32 lg:max-w-4xl xl:max-w-5xl xl:pl-8 2xl:max-w-7xl lg:mx-auto",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
      className: "text-lg text-center px-4 md:px-0",
      children: "Get in touch"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
      className: "text-4/5xl leading-tight lg:text-5xl font-medium my-5 text-center font-neueMachina px-4 md:px-0",
      children: ["Have a project in mind?  ", /*#__PURE__*/jsx_runtime_.jsx("br", {
        className: "hidden lg:inline-block"
      }), " Let's work together."]
    }), !success && /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [" ", /*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-xl text-center px-4 md:px-0",
        children: "Please fill out the form below and we will be in touch soon."
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("form", {
        onSubmit: formik.handleSubmit,
        className: "flex flex-col max-w-lg mx-auto mt-12 px-4 lg:px-0",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "my-8",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "border-b-2 focus-within:border-defi-blue relative ",
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              className: "block w-full appearance-none focus:outline-none bg-transparent pb-4",
              id: "name",
              name: "name",
              type: "text",
              placeholder: " ",
              onChange: formik.handleChange,
              value: formik.values.name
            }), /*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "absolute top-0 -z-1 duration-300 origin-0 text-gray-500",
              htmlFor: "name",
              children: "Your Name"
            })]
          }), formik.errors.name ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-red-600",
            children: formik.errors.name
          }) : null]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "my-8",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "border-b-2 focus-within:border-defi-blue relative",
            children: [/*#__PURE__*/jsx_runtime_.jsx("input", {
              className: "block w-full appearance-none focus:outline-none bg-transparent pb-4",
              id: "email",
              name: "email",
              type: "email",
              placeholder: " ",
              onChange: formik.handleChange,
              value: formik.values.email
            }), /*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "absolute top-0 -z-1 duration-300 origin-0 text-gray-500",
              htmlFor: "email",
              children: "Your email address"
            })]
          }), formik.errors.email ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-red-600",
            children: formik.errors.email
          }) : null]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "my-8",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "border-b-2 focus-within:border-defi-blue relative",
            children: [/*#__PURE__*/jsx_runtime_.jsx("textarea", {
              className: "block w-full appearance-none focus:outline-none bg-transparent",
              id: "message",
              name: "message",
              placeholder: " ",
              rows: 5,
              onChange: formik.handleChange,
              value: formik.values.message
            }), /*#__PURE__*/jsx_runtime_.jsx("label", {
              className: "absolute top-0 -z-1 duration-300 origin-0 text-gray-500",
              htmlFor: "message",
              children: "Describe your project"
            })]
          }), formik.errors.message ? /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "text-red-600",
            children: formik.errors.message
          }) : null]
        }), /*#__PURE__*/jsx_runtime_.jsx("button", {
          type: "submit",
          className: "px-8 py-3 mt-5 bg-defi-blue text-white lg:self-end",
          children: "Submit"
        })]
      })]
    }), success && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col justify-center items-center",
      children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
        className: "text-xl text-defi-blue px-4 md:px-0",
        children: "Your message was sent!  We\u2019ll get back to you shortly."
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "relative",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "absolute inset-0 w-full h-full flex justify-center items-center z-10",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/success.svg",
            alt: "email successfully sent",
            width: 190,
            height: 190
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
          src: "/successArt.gif",
          alt: "email successfully sent",
          width: 362,
          height: 362
        })]
      })]
    })]
  });
};

/* harmony default export */ var components_ContactForm = (ContactForm);
// EXTERNAL MODULE: ./components/Meta.tsx
var Meta = __webpack_require__(1112);
;// CONCATENATED MODULE: ./components/Layout/Layout.tsx










const Layout = props => {
  const {
    children
  } = props;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Meta/* default */.Z, {}), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "font-avenir",
      children: [/*#__PURE__*/jsx_runtime_.jsx(Layout_Navbar, {}), children, /*#__PURE__*/jsx_runtime_.jsx(components_ContactForm, {}), /*#__PURE__*/jsx_runtime_.jsx("footer", {
        className: "mt-32 lg:max-w-4xl xl:max-w-5xl xl:pl-8 2xl:max-w-7xl lg:mx-auto px-4 lg:px-0",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "grid md:grid-cols-3 gap-12",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: "/blueLogo.svg",
                alt: "the defi network logo",
                width: 40,
                height: 40
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "text-lg",
                children: "Step into blockchain."
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "mb-3 font-bold",
                children: "Contact us \u2014"
              }), /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                href: "mailto:info@thedefi.network",
                children: "info@thedefi.network"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                className: "mb-3 mt-16 font-bold",
                children: "Location \u2014"
              }), /*#__PURE__*/jsx_runtime_.jsx("p", {
                children: "California, USA"
              })]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
              className: "flex gap-20 lg:gap-0 lg:justify-between lg:pl-8",
              children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("ul", {
                className: "space-y-5",
                children: [/*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#home",
                    children: "Home"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#projects",
                    children: "Projects"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#services",
                    children: "Services"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#technologies",
                    children: "Technologies"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#team",
                    children: "Team"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#partnerships",
                    children: "Partnerships"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#faq",
                    children: "FAQ's"
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "/#contact",
                    children: "Get in touch"
                  })
                })]
              }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
                className: "space-y-5",
                children: /*#__PURE__*/jsx_runtime_.jsx("li", {
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
                    href: "https://twitter.com/thedefinetwork",
                    children: "Twitter"
                  })
                })
              })]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "pt-20 pb-5",
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
              children: ["\xA9 Copyright ", new Date().getFullYear(), " The Defi Network. All rights reserved."]
            })
          })]
        })
      })]
    })]
  });
};

/* harmony default export */ var Layout_Layout = (Layout);
;// CONCATENATED MODULE: ./pages/_app.tsx


function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




function MyApp({
  Component,
  pageProps
}) {
  return /*#__PURE__*/jsx_runtime_.jsx(Layout_Layout, {
    children: /*#__PURE__*/jsx_runtime_.jsx(Component, _objectSpread({}, pageProps))
  });
}

/* harmony default export */ var _app = (MyApp);

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [297,61,724], function() { return __webpack_exec__(5990); });
module.exports = __webpack_exports__;

})();