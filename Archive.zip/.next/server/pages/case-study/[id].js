(function() {
var exports = {};
exports.id = 227;
exports.ids = [227];
exports.modules = {

/***/ 1057:
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": function() { return /* binding */ _id_; },
  "getStaticPaths": function() { return /* binding */ getStaticPaths; },
  "getStaticProps": function() { return /* binding */ getStaticProps; }
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./data/projectsData.tsx
var projectsData = __webpack_require__(3225);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
;// CONCATENATED MODULE: ./components/NextProjects.tsx





const NextProjects = props => {
  const projects = props.projects;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "mb-36 mt-36",
    children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
      className: "text-4/5xl lg:text-5xl leading-tight font-medium px-4 lg:px-0",
      children: "What\u2019s next?"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid gap-36 grid-cols-1 md:grid-cols-2 ",
      children: projects.map((project, index) => {
        return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: index === 0 ? 'mt-24' : '',
          children: [index === 1 && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "bg-gray-200",
            children: /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "pl-2 pt-2 md:pl-4 md:pt-4 lg:pl-8 lg:pt-8 flex",
              children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                src: project.image,
                alt: project.name,
                width: 498,
                height: 570,
                objectFit: "cover"
              })
            })
          }), index === 0 && /*#__PURE__*/jsx_runtime_.jsx("div", {
            children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
              src: project.image,
              alt: project.name,
              width: 497,
              height: 380,
              objectFit: "cover"
            })
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
            className: "text-2xl font-bold mt-4 px-4 lg:px-0",
            children: [project.name, " \u2014"]
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "mt-2 px-4 lg:px-0" + (index === 4 ? 'md:w-1/2' : 'w-full'),
            children: project.excerpt
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "mt-8 text-xl font-medium font-neueMachina px-4 lg:px-0",
            children: [/*#__PURE__*/jsx_runtime_.jsx("br", {}), /*#__PURE__*/jsx_runtime_.jsx("a", {
              href: project.projectLink,
              target: "_blank",
              children: "View Project \u2197"
            })]
          })]
        }, index);
      })
    })]
  });
};

/* harmony default export */ var components_NextProjects = (NextProjects);
// EXTERNAL MODULE: ./components/Meta.tsx
var Meta = __webpack_require__(1112);
;// CONCATENATED MODULE: ./pages/case-study/[id]/index.tsx










const CaseStudy = props => {
  const project = props.project;
  const projects = props.projects;
  const currentProjectIndex = projects.findIndex(proj => proj.id === project.id);
  const nextProjects = currentProjectIndex === projects.length - 1 ? [projects[0], projects[1]] : currentProjectIndex === projects.length - 2 ? [projects[projects.length - 1], projects[0]] : [projects[currentProjectIndex + 1], projects[currentProjectIndex + 2]];
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(Meta/* default */.Z, {
      title: project.name,
      description: project.caseStudy.abstract
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        id: "case-study",
        className: "mt-32 lg:max-w-4xl xl:max-w-5xl xl:pl-8 2xl:max-w-7xl lg:mx-auto",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h1", {
          className: "font-bold text-5xl px-4 lg:px-0",
          children: [" ", project === null || project === void 0 ? void 0 : project.name, " \u2014"]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "lg:grid lg:grid-cols-5 lg:gap-24 px-4 lg:px-0",
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "lg:col-span-3 lg:self-end pt-16",
            children: /*#__PURE__*/jsx_runtime_.jsx("p", {
              className: "text-2xl",
              dangerouslySetInnerHTML: {
                __html: project.caseStudy.abstract
              }
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("ul", {
            className: "col-span-2 space-y-3 text-lg hidden lg:block font-neueMachina",
            children: project.caseStudy.technologies.map((tech, index) => {
              return /*#__PURE__*/(0,jsx_runtime_.jsxs)("li", {
                children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
                  className: "mr-2",
                  children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
                    src: "/check.svg",
                    alt: "check icon",
                    width: 13,
                    height: 10
                  })
                }), tech]
              }, index);
            })
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "mt-20",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/project5.png",
            alt: "project image",
            width: 1154,
            height: 600,
            objectFit: "cover",
            objectPosition: "center center"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "max-w-screen-md mt-20 mx-auto px-4 lg:px-0",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "text-5xl",
            children: project.caseStudy.heading1
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "pt-5 ",
            children: project.caseStudy.description1
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "max-w-screen-lg flex gap-8 py-20",
          children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/project5.png",
            alt: "project image",
            width: 512,
            height: 363,
            objectFit: "cover",
            objectPosition: "center center"
          }), /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/project5.png",
            alt: "project image",
            width: 512,
            height: 363,
            objectFit: "cover",
            objectPosition: "center center"
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "max-w-screen-md mt-20 mx-auto px-4 lg:px-0",
          children: [/*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "pt-5",
            children: project.caseStudy.description2
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "py-20 text-defi-blue text-center font-neueMachina",
            children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "text-2xl ",
              children: ["\"", project.caseStudy.testimonial.text, "\""]
            }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
              className: "text-lg font-bold mt-4",
              children: ["\u2014 ", project.caseStudy.testimonial.employeeName, ", ", project.caseStudy.testimonial.emloyeeRole]
            })]
          }), /*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "text-5xl",
            children: project.caseStudy.heading2
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "pt-5",
            children: project.caseStudy.description3
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "my-20",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/project5.png",
            alt: "project image",
            width: 952,
            height: 635,
            objectFit: "cover",
            objectPosition: "center center"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "my-20 flex justify-end lg:mr-10",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/project5.png",
            alt: "project image",
            width: 650,
            height: 440,
            objectFit: "cover",
            objectPosition: "center center"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "my-20",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
            src: "/project5.png",
            alt: "project image",
            width: 952,
            height: 635,
            objectFit: "cover",
            objectPosition: "center center"
          })
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "max-w-screen-md mb-20 mx-auto px-4 lg:px-0",
          children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
            className: "text-5xl",
            children: "The result"
          }), /*#__PURE__*/jsx_runtime_.jsx("p", {
            className: "pt-5",
            children: project.caseStudy.resultDescription
          })]
        }), project.caseStudy.projectLink !== '' && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "max-w-screen-md mb-20 mx-auto px-4 lg:px-0",
          children: /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
            href: project.caseStudy.projectLink,
            children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
              className: "text-3xl",
              children: ["Visit ", project.name, " \u2197"]
            })
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "bg-gray-100 h-0.5 max-w-screen-md mx-auto"
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          children: /*#__PURE__*/jsx_runtime_.jsx(components_NextProjects, {
            projects: nextProjects
          })
        })]
      })
    })]
  });
};

const getStaticProps = async context => {
  const projects = projectsData/* ProjectData */.H;
  const project = projects.filter(proj => proj.id === context.params.id)[0];
  return {
    props: {
      project,
      projects
    }
  };
};
const getStaticPaths = async () => {
  const projects = projectsData/* ProjectData */.H;
  const ids = projects.map(proj => proj.id);
  const paths = ids.map(id => ({
    params: {
      id: id
    }
  }));
  return {
    paths,
    fallback: false
  };
}; // const router = useRouter()
// const { id } = router.query
// const projects = ProjectData
// const [project, setProject] = useState<any>(null);
// useEffect(() => {
//     setProject(projects.filter(proj => proj.id === id)[0]);
// }, [projects]);

/* harmony default export */ var _id_ = (CaseStudy);

/***/ }),

/***/ 5273:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/head.js");;

/***/ }),

/***/ 8417:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router-context.js");;

/***/ }),

/***/ 2238:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/router/utils/get-asset-path-from-route.js");;

/***/ }),

/***/ 5519:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/lib/to-base-64.js");;

/***/ }),

/***/ 444:
/***/ (function(module) {

"use strict";
module.exports = require("next/dist/next-server/server/image-config.js");;

/***/ }),

/***/ 701:
/***/ (function(module) {

"use strict";
module.exports = require("next/head");;

/***/ }),

/***/ 9297:
/***/ (function(module) {

"use strict";
module.exports = require("react");;

/***/ }),

/***/ 5282:
/***/ (function(module) {

"use strict";
module.exports = require("react/jsx-runtime");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = __webpack_require__.X(0, [297,61,724,225], function() { return __webpack_exec__(1057); });
module.exports = __webpack_exports__;

})();