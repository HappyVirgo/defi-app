export const ImageGridData: GridImage[] = [
    { image: '/imageGrid/gridImage1.png' },
    { image: '/imageGrid/gridImage2.png' },
    { image: '/imageGrid/gridImage3.png' },
    { image: '/imageGrid/gridImage4.png' },
    { image: '/imageGrid/gridImage5.png' },
    { image: '/imageGrid/gridImage6.png' },
    { image: '/imageGrid/gridImage7.png' },
    { image: '/imageGrid/gridImage8.png' },
    { image: '/imageGrid/gridImage9.png' },
    { image: '/imageGrid/gridImage6.png' },
    { image: '/imageGrid/gridImage11.png' }

];


export interface GridImage {
    image: string
}
